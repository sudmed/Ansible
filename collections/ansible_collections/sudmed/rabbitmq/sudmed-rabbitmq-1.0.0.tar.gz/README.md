# Ansible Collection - sudmed.rabbitmq

Documentation for the collection.
